package com.cg.sessionschedulemanagementsystem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.sessionschedulemanagementsystem.beans.SessionSchedule;



@Repository("sessiondao")
public class SessionDaoImpl implements ISessionDao{
	
	@PersistenceContext
	EntityManager em;				
	
	
	
	//------------------------ 1. Session Schedule Management System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getSessionSchedule()
		 - Input Parameters	:	
		 - Author			:	CAPGEMINI
		 - Return Type		:	List
		 - Creation Date	:	11/01/2018
		 - Description		:	Retrieving data from database via SessionSchedule Class and returning to service class
		 ********************************************************************************************************/

	@SuppressWarnings("unchecked")
	@Override
	public List<SessionSchedule> getSessionSchedule() {

		Query query= em.createQuery("FROM SessionSchedule");
		List<SessionSchedule> list=query.getResultList();
		
		return list;
	}

}
