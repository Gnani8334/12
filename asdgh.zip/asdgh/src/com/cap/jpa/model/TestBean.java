package com.cap.jpa.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Entity(name="query")
@Transactional
public class TestBean {
	
	@Id
	private Integer queryID;
	
	String technology;
	String queryraisedby;
	String query;
	String solutions;
	String givenby;
	public Integer getQueryID() {
		return queryID;
	}
	public void setQueryID(Integer queryID) {
		this.queryID = queryID;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	
	public String getQueryraisedby() {
		return queryraisedby;
	}
	public void setQueryraisedby(String queryraisedby) {
		this.queryraisedby = queryraisedby;
	}
	public String getGivenby() {
		return givenby;
	}
	public void setGivenby(String givenby) {
		this.givenby = givenby;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	
	

}
