package com.cg.lh.service;

import java.util.List;

import com.cg.lh.dto.Leave;




public interface ILeaveService {

	public List<Leave> searchleave(int empId);
}
