package com.cg.lh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lh.dto.Leave;
import com.cg.lh.service.ILeaveService;





@Controller
public class LeaveController {

	@Autowired
	ILeaveService leaveservice;
	
	
	@RequestMapping(value="searchleave", method=RequestMethod.GET)
	public String searchData(@ModelAttribute("yy") Leave lev){
		return "searchleave";
	}
	
	@RequestMapping(value="leavesearch", method=RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("yy") Leave lev)
	{
		System.out.println("reaced here");
		System.out.println(lev.getEmpid());
		List<Leave> levSearch=leaveservice.searchleave(lev.getEmpid());
		System.out.println(levSearch);
		return new ModelAndView("ViewLeaveDetails","temp",levSearch);
	}
	
}
