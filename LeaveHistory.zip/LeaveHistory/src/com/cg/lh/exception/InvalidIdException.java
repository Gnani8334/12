package com.cg.lh.exception;

public class InvalidIdException extends Exception{

	public InvalidIdException() {
		super();
		
	}

	
	

}
