package com.cg.lh.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class Employee {

	@Id
	@Column(name="empid")
	Integer empid;
	
	@Column(name="ename")
	String employeeName;
	
	@Column(name="address")
	String address;
	@Column(name="leaves_avail")
	Integer leaves_avail ;
	
	public Employee(Integer empid, String employeeName, String address,
			Integer leaves_avail) {
		super();
		this.empid = empid;
		this.employeeName = employeeName;
		this.address = address;
		this.leaves_avail = leaves_avail;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", employeeName="
				+ employeeName + ", address=" + address + ", leaves_avail="
				+ leaves_avail + "]";
	}
	public Employee() {
		super();
	}
	public Integer getempid() {
		return empid;
	}
	public void setempid(Integer empid) {
		this.empid = empid;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getLeaves_avail() {
		return leaves_avail;
	}
	public void setLeaves_avail(Integer leaves_avail) {
		this.leaves_avail = leaves_avail;
	}
	 
	 
	 
}
