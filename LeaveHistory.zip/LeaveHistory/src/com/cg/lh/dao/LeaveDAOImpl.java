package com.cg.lh.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;






import com.cg.lh.dto.Leave;



@Repository("leavedao")
public class LeaveDAOImpl implements ILeaveDAO {

	@PersistenceContext
	EntityManager  em;

	@Override
	public List<Leave> searchLeave(int empid) {
		// TODO Auto-generated method stub
		System.out.println("id in"+empid);
		//Leave lev1=em.find(Leave.class,empid);
	Query querysearch=em.createQuery("FROM Leave WHERE empid=:empid");
	querysearch.setParameter("empid",empid);
	List<Leave>myAll= querysearch.getResultList();
	System.out.println(myAll);
		return myAll;
	
	
}
}