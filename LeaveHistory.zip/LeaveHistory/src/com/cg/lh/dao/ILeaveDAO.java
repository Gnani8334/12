package com.cg.lh.dao;

import java.util.List;

import com.cg.lh.dto.Leave;

public interface ILeaveDAO {

	

	public List<Leave> searchLeave(int empId);
}
